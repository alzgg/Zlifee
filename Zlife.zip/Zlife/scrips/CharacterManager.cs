using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class CharacterManager : MonoBehaviour
{
    public List<CharacterData> characters;
    public GameObject playerPrefab;
    public Transform spawnPoint;

    public GameObject characterSelectionUI;
    public GameObject characterButtonPrefab;

    void Start()
    {
        foreach (var character in characters)
        {
            GameObject button = Instantiate(characterButtonPrefab, characterSelectionUI.transform);
            button.GetComponentInChildren<Text>().text = character.characterName;

            button.GetComponent<Button>().onClick.AddListener(() => {
                SpawnCharacter(character);
                characterSelectionUI.SetActive(false);
            });
        }
    }

    void SpawnCharacter(CharacterData character)
    {
        GameObject player = Instantiate(playerPrefab, spawnPoint.position, Quaternion.identity);
        PlayerController controller = player.GetComponent<PlayerController>();
        controller.SetCharacter(character);
    }
}
