using UnityEngine;

[System.Serializable]
public class CharacterData
{
    public string characterName;
    public float moveSpeed;
    public int maxHealth;
    public Sprite characterSprite;
}
